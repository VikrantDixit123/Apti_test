// All the Action Types which will be used in actions and reducers will remain here
const ActionTypes = {
    SET_ANSWER: 'SET_ANSWER',
    SET_TIME: 'SET_TIME'
};

export default ActionTypes;
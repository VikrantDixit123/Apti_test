// This variable defines initialState of redux store.
const initialState = {
    userAnswers: {},
    time: 1
};

export default initialState;
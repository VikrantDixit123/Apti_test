import React from 'react';

const Footer = (props) => {
    return (
        <footer className = "footer">
            <h5>Copyright &copy; Xoriant</h5>
        </footer>
    );
};

export default Footer;

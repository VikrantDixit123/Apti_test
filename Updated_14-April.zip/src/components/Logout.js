import React from 'react'

class Logout extends React.Component{
    render(){
        return(
            <div className = "logout">
                <h1>Thank you</h1>
            </div>
        )
    }
}

export default Logout